title: ReadMore 之 cnblogs 博客园使用指南
date: '2019-10-17 14:30:32'
updated: '2019-10-17 14:30:32'
tags: [blog]
permalink: /201910171430blog
---
![](https://img.hacpai.com/bing/20180330.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

readmore来源于：https://openwrite.cn/openwrite/openwrite-readmore/

博客园接入 readmore 很简单，三步走，2 分钟搞定！

1. 在 OpenWrite 生成 readmore 脚本

2. 微信公众号设置关键词回复

3. 在博客园设置中添加脚本

第一步， 在 OpenWrite 生成 readmore 脚本

在 OpenWrite 后台，增长工具 / 博客导流公众号 目录下。点击添加按钮，填写博客和公众号信息，生成 readmore 脚本。
![custom](http://www.liabio.cn/img/2019-10-16-cnblog-readmore/readmore1.png)

第二步， 微信公众号设置关键词回复

保存成功后在列表页中点击使用，根据使用指南设置公众号关键词回复，并复制 readmore 脚本。

第三步，在博客园设置中添加脚本

打开博客园，管理 / 设置页面，在最下方 页脚Html代码 中添加第二步中复制的代码，修改代码中的 id 为 cnblogs_post_body 点击保存。 
![custom](http://www.liabio.cn/img/2019-10-16-cnblog-readmore/readmore3.png)




OK，再打开文章页面看看，文章是否隐藏了部分内容，最后出现了“阅读全文”按钮？ 
![custom](http://www.liabio.cn/img/2019-10-16-cnblog-readmore/readmore4.png) 

